﻿using System;
using System.Linq;
using System.Windows;
namespace SportsStoreApp
{
    public partial class LoginForm : Window
    {
        // Создаем контекст базы данных
        private sportApp_chartorizskij_V db = new sportApp_chartorizskij_V();

        public LoginForm()
        {
              InitializeComponent();
            db = 
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Проверка полей
            if (string.IsNullOrWhiteSpace((string)txtEmail.Text))
            {
                MessageBox("Введите email");
                return;
            }

            if (txtPassword.Password == "")
            {
                MessageBox("Введите пароль");
                return;
            }

            try
            {
                // Ищем пользователя в базе
                var user = db.Users.FirstOrDefault(u => u.Email == txtEmail.Text);

                if (user == null)
                {
                    MessageBox("Пользователь не найден");
                    return;
                }

                // Проверяем пароль
                if (user.PasswordHash == txtPassword.Password)
                {
                    // Успешный вход
                    System.Windows.MessageBox.Show($"Добро пожаловать, {user.Email}!", "Успех",
                     MessageBoxButton.OK, MessageBoxImage.Information);

                    // Открываем главное окно
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();

                    // Закрываем окно авторизации
                    this.Close();
                }
                else
                {
                    MessageBox("Неверный пароль");
                }
            }
            catch (Exception ex)
            {
                MessageBox("Ошибка подключения к БД: " + ex.Message);
            }
        }

        private void MessageBox(string v)
        {
            throw new NotImplementedException();
        }

        private void ShowError(string message)
        {
            txtError.Text = message;
            txtError.Visibility = Visibility.Visible;
        }
    }
}
