﻿namespace SportsStoreApp
{
    internal class txtEmail
    {
        internal static object Text;
    }
}