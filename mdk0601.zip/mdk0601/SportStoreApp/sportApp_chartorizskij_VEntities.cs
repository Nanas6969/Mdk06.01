﻿namespace SportsStoreApp
{
    internal class sportApp_chartorizskij_VEntities
    {
        public sportApp_chartorizskij_VEntities()
        {
        }
    }
}