﻿using System;

namespace SportsStoreApp
{
    internal class sportApp_chartorizskij_V
    {
        internal void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}