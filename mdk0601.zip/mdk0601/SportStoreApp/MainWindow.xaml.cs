﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Linq;


namespace SportsStoreApp
{
    public partial class LoginForm : Window
    {
        // Создаем контекст базы данных
        private sportApp_chartorizskij_VEntities db = new sportApp_chartorizskij_VEntities();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            // Проверка полей
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                ShowError("Введите email");
                return;
            }

            if (txtPassword.Password == "")
            {
                ShowError("Введите пароль");
                return;
            }

            try
            {
                // Ищем пользователя в базе
                var user = db.Users.FirstOrDefault(u => u.Email == txtEmail.Text);

                if (user == null)
                {
                    ShowError("Пользователь не найден");
                    return;
                }

                // Проверяем пароль
                if (user.PasswordHash == txtPassword.Password)
                {
                    // Успешный вход
                    MessageBox.Show($"Добро пожаловать, {user.Email}!", "Успех",
                        MessageBoxButton.OK, MessageBoxImage.Information);

                    // Открываем главное окно
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();

                    // Закрываем окно авторизации
                    this.Close();
                }
                else
                {
                    ShowError("Неверный пароль");
                }
            }
            catch (Exception ex)
            {
                ShowError("Ошибка подключения к БД: " + ex.Message);
            }
        }

        private void ShowError(string message)
        {
            txtError.Text = message;
            txtError.Visibility = Visibility.Visible;
        }
    }
}
