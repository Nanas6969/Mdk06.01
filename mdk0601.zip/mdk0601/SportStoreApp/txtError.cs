﻿using System.Windows;

namespace SportsStoreApp
{
    internal class txtError
    {
        internal static Visibility Visibility;

        public static string Text { get; internal set; }
    }
}