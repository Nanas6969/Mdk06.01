﻿namespace SportsStoreApp
{
    internal class txtPassword
    {
        internal static string Password;
    }
}